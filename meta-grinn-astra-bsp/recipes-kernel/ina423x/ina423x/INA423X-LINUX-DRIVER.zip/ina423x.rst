.. SPDX-License-Identifier: GPL-2.0-only

Kernel driver ina423x
====================

Supported chips:

  * Texas Instruments INA4235

    Prefix: 'ina4235'

    Addresses: I2C 0x40 - 0x4f

    Datasheet:
	https://www.ti.com/lit/ds/symlink/ina4235.pdf

  * Texas Instruments INA4230

    Prefix: 'ina4230'

    Addresses: I2C 0x40 - 0x4f

    Datasheet:
	https://www.ti.com/lit/ds/symlink/ina4230.pdf

  * Texas Instruments INA423x

    Prefix: 'ina423x'

    Addresses: I2C 0x40 - 0x4f

    Datasheet:
	https://www.ti.com/lit/ds/symlink/ina4235.pdf

Author: Mitch Morse <mitchmorse@ti.com>

Description
-----------

The Texas Instruments INA4235 and INA4230 devices are 48V, Quad Channel, 16-Bit, Ultra - Precise, 
Current, Voltage, Power, and Energy Monitors With an I2C Interface. The devices feature 4 alert 
channels and configurable conversion times and averaging. The driver lets you configure a 
generic ina423x device if you will be using either the INA4235 or INA4230. 

The device tree can be used to provide labels for each channel, as well as for configuring each 
channel's shunt resistor value in micro-ohms and ADCRANGE via the shunt-gain parameter. The device 
alert polarity can also be can be can be configured from device tree data. Please refer to 
Documentation/devicetree/bindings/hwmon/ti,ina423x.yaml for binding information.

Sysfs entries
-------------

=================================== ==================================================================================
in[1234]_input	                    Bus voltage (mV) channels
in[5678]_input	                    Shunt voltage (µV) channels
curr[1234]_input	                Current (mA) channels
power[1234]_input	                Power (µW) channels
energy[1234]_input	                Energy (µJ) channels
energy[1234]_overflow	            Energy overflow alarm 
energy[1234]_reset	                Energy accumulation reset and overflow clear
channel[1234]_label	                Channel label from the Device Tree
channel[1234]_enable	            Enable/disable whole channel conversions
	
                                    * 1: Enable channel (default)
                                    * 0: Disable channel
	
	                                \*If in triggered mode, writing to this field will trigger a conversion.
conversion_mode	                    Conversion mode for both bus and shunt
	
                                    * 0: Triggered mode\*
                                    * 1: Continuous mode (default)
	
	                                \*Writing 0 to this field also triggers a conversion.
conversion_enable_bus	            Enable/disable bus voltage conversions
	
                                    * 1: Enable conversions (default)
                                    * 0: Disable conversions
                                    
                                    \*If in triggered mode, writing to this field will trigger a conversion.
conversion_enable_shunt	            Enable/disable shunt voltage conversions
	
                                    * 1: Enable conversions (default)
                                    * 0: Disable conversions
                                    
                                    \*If in triggered mode, writing to this field will trigger a conversion.
conversion_time_bus_us	            Conversion time (µs) to use for the bus. Default: 1100
	
	                                Supports the list of conversion times:
	
                                    140, 204, 332, 588, 1100, 2116, 4156, 8244
	
                                    \*If in triggered mode, writing to this field will trigger a conversion.
conversion_time_shunt_us	        Conversion time (µs) to use for the shunt. Default: 1100
	
                                    Supports the list of conversion times:
                                    
                                    140, 204, 332, 588, 1100, 2116, 4156, 8244
                                    
                                    \*If in triggered mode, writing to this field will trigger a conversion.
samples 	                        Number of samples to use for the averaging mode. Default: 1
	
                                    Supports the list of number of samples:
                                    
                                    1, 4, 16, 64, 128, 256, 512, 1024
                                    
                                    \*If in triggered mode, writing to this field will trigger a conversion.
conversion_ready	                Conversion ready alarm
alert_pin_enable_conversion_ready   Enable/disable the conversion ready alarm on the alert pin
	
                                    * 0: Disable conversion ready alarm on the alert pin (default)
                                    * 1: Enables conversion ready alarm on the alert pin
                                    
                                    ALERT remains asserted until the conversion_ready entry is read. 
                                    (Or any of the entries listed in flags_register entry). 
alert_pin_enable_energy_overflow	Enable/disable the energy overflow alarm on the alert pin
	
                                    * 0: Disable energy overflow alarm on the alert pin (default)
                                    * 1: Enables energy overflow alarm on the alert pin
alert_pin_mode	                    Set the mode for the alert pin behavior
	
                                    * 0: Transparent mode (default)
                                    * 1: Latched mode
alarm[1234]_channel	                The channel to be used for the alarm:
	
                                    * 1: Channel 1 (default)
                                    * 2: Channel 2
                                    * 3: Channel 3
                                    * 4: Channel 4
alarm[1234]_mode	                The Alert type for the alarm:
	
                                    * 0: Alert Disabled (default)
                                    * 1: Shunt Voltage over limit (SOL)
                                    * 2: Shunt Voltage under limit (SUL)
                                    * 3: Bus Voltage over limit (BOL)
                                    * 4: Bus Voltage under limit (BUL)
                                    * 5: Power over limit (POL)
alarm[1234]_limit	                Limit threshold for the Alarm. Must configure alarm[1234]_mode first. Default: 0
                                    
                                    Units based on alarm mode type:
                                        
                                    * SOL/SUL: µV
                                    * BOL/BUL: mV
                                    * POL: µW
                                    
                                    Must set alarm[1234]_mode before using alarm[1234]_limit
alarm[1234]	                        The alarm for each alarm channel
flags_register	                    Reads the raw flags register for processing alerts together. 
                                    
                                    Register bits correspond to the following alerts:
	
                                    * Bit 15: alarm4
                                    * Bit 14: alarm3
                                    * Bit 13: alarm2
                                    * Bit 12: alarm1
                                    * Bit 11: energy4_overflow
                                    * Bit 10: energy3_overflow
                                    * Bit 9: energy2_overflow
                                    * Bit 8: energy1_overflow
                                    * Bit 7: conversion_ready
                                    * Bit 6: math_overflow (driver does not support this individually)
                                    * Bits 5-0: reserved
	
	                                If alert_pin_mode is set to "Latched mode", use flags_register entry instead of 
                                    individual alarm entries to get all alert info without clearing unseen alarms.
=================================== ==================================================================================

